# AppDynamics DashTime!

## From 12 AM - Next Hour Always!